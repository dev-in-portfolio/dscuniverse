#!/usr/bin/env python3
"""Visually designed reader-facing summary; figures sourced from verified v2 JSON."""
from __future__ import annotations

import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.utils import simpleSplit
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'healthcare_model_correction_20261031' / 'Model_Correction_Reconciliation.json'
OUT = ROOT / 'outputs' / 'healthcare_polish_v3' / 'Universal_Healthcare_Technical_Brief_v3.pdf'
OUT.parent.mkdir(parents=True, exist_ok=True)
data = json.loads(SOURCE.read_text())
old = data['legacy_outputs_T']['30']
new = data['corrected_outputs_T']['30']
century = data['corrected_outputs_T']['100']

pdfmetrics.registerFont(TTFont('DejaVu', '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DejaVu-Bold', '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))

NAVY = colors.HexColor('#102935')
NAVY2 = colors.HexColor('#193C49')
INK = colors.HexColor('#213541')
TEAL = colors.HexColor('#13918B')
TEAL_PALE = colors.HexColor('#E6F5F2')
GOLD = colors.HexColor('#C49A56')
SAND = colors.HexColor('#FFF6E8')
RED = colors.HexColor('#A74442')
RED_PALE = colors.HexColor('#FBEFEC')
MUTED = colors.HexColor('#617783')
LINE = colors.HexColor('#E0E8EA')
WHITE = colors.white
PALE = colors.HexColor('#F5F7F8')
W,H=612,792
c=canvas.Canvas(str(OUT),pagesize=(W,H),pageCompression=1)
c.setTitle('Universal healthcare: corrected source-driven model | Technical brief v3')
c.setAuthor('Dark Star Consulting Group')
c.setSubject('30- and 100-year conditional national expenditure model and verified source lineage')

def block(x,y,w,h,color,radius=0):
    c.setFillColor(color); c.setStrokeColor(color)
    if radius:c.roundRect(x,y,w,h,radius,stroke=0,fill=1)
    else:c.rect(x,y,w,h,stroke=0,fill=1)

def line(x1,y1,x2,y2,color=LINE,width=1):
    c.setStrokeColor(color);c.setLineWidth(width);c.line(x1,y1,x2,y2)

def text(x,y,value,size=10,bold=False,color=INK,align='left'):
    font='DejaVu-Bold' if bold else 'DejaVu'
    c.setFont(font,size);c.setFillColor(color)
    if align=='right':c.drawRightString(x,y,str(value))
    elif align=='center':c.drawCentredString(x,y,str(value))
    else:c.drawString(x,y,str(value))

def paragraph(x,y,value,width,size=9.5,leading=15,color=MUTED,bold=False):
    font='DejaVu-Bold' if bold else 'DejaVu'
    for row in simpleSplit(value,font,size,width):
        text(x,y,row,size,bold,color);y-=leading
    return y

def foot(page):
    line(42,43,570,43)
    text(42,27,'DARK STAR  /  UNIVERSAL HEALTHCARE STUDY',7.5,True,MUTED)
    text(570,27,f'REVIEW COPY  |  {page} / 3',7.5,True,MUTED,'right')

def top_header(kicker,title,desc,page):
    block(0,675,W,117,NAVY)
    text(42,755,'DARK STAR CONSULTING GROUP',9,True,TEAL)
    text(570,755,f'SOURCE-DRIVEN MODEL  /  V3',8,True,colors.HexColor('#B8CDD1'),'right')
    line(42,742,570,742,colors.HexColor('#476570'))
    text(42,715,kicker,8.5,True,GOLD)
    text(42,684,title,21,True,WHITE)
    text(42,652,desc,8.7,False,MUTED)

def money(v,precision=3):
    if v<0:return f'({abs(v):,.{precision}f})'
    return f'{v:,.{precision}f}'

def status_label(x,y,label,kind='neutral'):
    bg,fg=(TEAL_PALE,TEAL) if kind=='good' else (RED_PALE,RED) if kind=='warn' else (PALE,MUTED)
    block(x,y,103,22,bg,5)
    text(x+51.5,y+7,label,7.7,True,fg,'center')

## PAGE 1: Main story and scenario picture.
block(0,510,W,282,NAVY)
block(42,742,72,3,TEAL)
text(42,759,'DARK STAR CONSULTING GROUP',8.8,True,colors.HexColor('#A5CED0'))
text(570,759,'2026  /  TECHNICAL REVIEW',8.2,True,colors.HexColor('#A5CED0'),'right')
text(42,690,'Universal coverage.',25,True,WHITE)
text(42,654,'A costed thought experiment.',23,True,WHITE)
text(42,613,'30-YEAR CENTRAL RESULT  /  2025-2054',9.3,True,colors.HexColor('#8EE5DC'))
text(42,557,f'+${new["D_minus_A_T"]:,.3f}T',39,True,WHITE)
text(365,565,'ADDITIONAL NATIONAL',9.3,True,colors.HexColor('#A5CED0'))
text(365,546,'HEALTH SPENDING',9.3,True,colors.HexColor('#A5CED0'))
block(42,481,528,1,GOLD)

text(42,456,'Four spending scenarios',14,True,INK)
text(570,459,'USD trillions, 2025-2054',8.5,False,MUTED,'right')
block(42,430,528,19,NAVY2)
text(54,436,'CASE',8,True,WHITE)
text(121,436,'DESIGN',8,True,WHITE)
text(470,436,'TOTAL',8,True,WHITE,'right')
text(558,436,'VS A',8,True,WHITE,'right')
scenarios=[
 ('A','Status quo',new['A_T'],0),
 ('B','Universal care + admin credit',new['B_T'],new['B_T']-new['A_T']),
 ('C','Current care + price credit',new['C_T'],new['C_T']-new['A_T']),
 ('D','Universal care + price + admin credits',new['D_T'],new['D_minus_A_T']),
]
for i,(key,label,total,delta) in enumerate(scenarios):
    y=404-i*26
    block(42,y-8,528,26,SAND if key=='D' else (PALE if i%2==0 else WHITE))
    text(54,y,key,10,True,TEAL if key=='D' else INK)
    text(121,y,label,9,False,INK)
    text(470,y,money(total),9,True,INK,'right')
    text(558,y,'-' if i==0 else (f'+{delta:,.3f}' if delta>0 else money(delta)),9,True,RED if delta>0 else TEAL,'right')

text(42,290,'Where the 30-year difference comes from',13,True,INK)
text(42,270,'Modelled additions and credits, measured against the same status quo.',8.6,False,MUTED)
bridge=[
 ('Expanded care',new['B0_T']-new['A_T'],NAVY2),
 ('Price credit',-new['price_credit_T'],TEAL),
 ('Admin credit',-new['admin_credit_T'],TEAL),
 ('Net additional',new['D_minus_A_T'],GOLD),
]
for i,(label,value,color) in enumerate(bridge):
    y=239-37*i
    text(42,y,label,9,True,INK)
    text(266,y,f'{value:+.3f}T',9,True,RED if value>0 and i==3 else color,'right')
    block(289,y-3,252,11,PALE,3)
    block(289,y-3,max(2,abs(value)/25.66*252),11,color,3)
line(42,81,570,81)
text(42,67,'The central case remains more expensive. More aggressive price cases are sensitivities.',8.2,False,MUTED)
foot(1);c.showPage()

## PAGE 2: Reconciliation, methodology, and original source lineage.
top_header('01  /  SOURCE RECOVERY','Two corrections. No new savings assumptions.',
           'The original generating model has been recovered and the starting value corrected.',2)
text(42,616,'Recovered 30-year expansion generator',14,True,INK)
paragraph(42,594,'The historical Step48 workbook provides the annual backlog queue, catch-up delivery ceiling, ongoing care and capacity addition. Its year-by-year B0 values match the reconstructed old-anchor model exactly.',528,9.1,15)
block(42,508,528,45,TEAL_PALE,6)
text(58,533,'ORIGINAL 30-YEAR B0',8.3,True,TEAL)
text(58,514,f'${old["B0_T"]:.9f} trillion',14,True,NAVY)
text(554,517,'Matches published control',8,True,TEAL,'right')

text(42,478,'Baseline correction',14,True,INK)
block(42,423,249,45,PALE,5)
block(301,423,269,45,SAND,5)
text(54,451,'PREVIOUS WORKING INPUT',8.2,True,MUTED)
text(54,431,'$5,278.600 billion',14,True,INK)
text(314,451,'CORRECTED SOURCE INPUT',8.2,True,TEAL)
text(314,431,'$5,278.588 billion',14,True,INK)

text(42,390,'30-year spending totals',13.5,True,INK)
block(42,365,528,18,NAVY2)
text(54,371,'SCENARIO',8,True,WHITE)
text(374,371,'ORIGINAL',8,True,WHITE,'right')
text(485,371,'CORRECTED',8,True,WHITE,'right')
text(557,371,'CHANGE',8,True,WHITE,'right')
table=[('A - baseline','A_T'),('B0 - expanded care','B0_T'),('B - universal','B_T'),('C - price case','C_T'),('D - combined','D_T'),('D less A','D_minus_A_T')]
for i,(label,key) in enumerate(table):
    y=346-i*27
    block(42,y-8,528,25,SAND if i==5 else (PALE if i%2==0 else WHITE))
    text(54,y,label,9.0,i==5,INK)
    text(374,y,money(old[key],6),8.7,i==5,INK,'right')
    text(485,y,money(new[key],6),8.7,i==5,INK,'right')
    text(557,y,f'{(new[key]-old[key])*1000:+.2f}B',8.3,i==5,RED if i==5 else MUTED,'right')

text(42,176,'The combined 30-year result changes by approximately -$35.65 million.',8.3,False,MUTED)

text(42,156,'Source-driven calculation (billions, annually)',12,True,INK)
block(42,113,528,34,PALE,5)
text(55,131,'A  +  new ongoing care  +  backlog delivered  +  added capacity  =  B0',9.4,True,NAVY)
text(55,119,'B0  -  limited price credit  -  insurer admin credit  =  D',9.4,True,TEAL)
paragraph(42,99,'The 2024 personal-care reference changed to $4,510.222B, but is not added to A. All original source workbooks are preserved unchanged.',528,7.9,12)
foot(2);c.showPage()

## PAGE 3: Sensitivity, validation and reviewer boundaries.
top_header('02  /  REVIEW BOUNDARIES','What the model does - and does not - establish.',
           'Reproducible arithmetic, with material feasibility questions still unanswered.',3)
text(42,617,'Price sensitivity: 30-year D minus A',14,True,INK)
text(570,620,'USD trillions',8.7,False,MUTED,'right')
alts=[
 ('Central limited-price',new['D_minus_A_T']),
 ('JAMA illustration',new['JAMA_D_minus_A_T']),
 ('Milliman + RAND',new['Milliman_RAND_D_minus_A_T']),
 ('Milliman + HCCI',new['Milliman_HCCI_D_minus_A_T']),
 ('RAND + Milliman',new['RAND_Milliman_D_minus_A_T']),
]
for i,(label,value) in enumerate(alts):
    y=585-30*i
    block(42,y-9,528,27,SAND if i==0 else (PALE if i%2==0 else WHITE))
    text(54,y,label,9.6,i==0,INK)
    text(554,y,f'{value:+.3f}',10.7,True,RED if value>0 else TEAL,'right')
paragraph(42,427,'These alternative price cases use mixed source populations and an assumed provider-support allowance. They are sensitivities, not guaranteed negotiated rates.',528,8.4,13)

text(42,386,'Four remaining feasibility gates',14,True,INK)
gates=[
 ('01','Provider-safe reimbursement','Do negotiated payment levels support continued care delivery?'),
 ('02','Staffed clinical capacity','Can hospitals, clinicians and supply chains actually serve unmet demand?'),
 ('03','Transition financing','How are cash needs bridged when payers and provider revenues change?'),
 ('04','Measured net health benefit','What clinical outcomes justify the additional resources used?'),
]
for i,(n,label,detail) in enumerate(gates):
    y=349-48*i
    block(42,y-20,528,42,PALE,5)
    block(53,y-9,27,25,NAVY2,5)
    text(66,y-1,n,8.3,True,WHITE,'center')
    text(91,y+4,label,9.4,True,INK)
    text(91,y-11,detail,8.1,False,MUTED)

block(42,92,528,63,TEAL_PALE,7)
text(54,135,'IMPORTANT RESEARCH LIMITATION',9.1,True,TEAL)
paragraph(54,117,'No additional dollars are credited for prior-authorization paperwork removal, unified public procurement, fraud, medical debt or earlier diagnoses. Those effects still require real-world evidence and careful cost accounting.',502,8.2,12,INK)

text(42,76,'2025-2124 central D - A: +$%0.3fT. This is a nominal extrapolation, not a century forecast.'%century['D_minus_A_T'],7.7,False,MUTED)
foot(3);c.showPage()
c.save()
print('CREATED',OUT)
