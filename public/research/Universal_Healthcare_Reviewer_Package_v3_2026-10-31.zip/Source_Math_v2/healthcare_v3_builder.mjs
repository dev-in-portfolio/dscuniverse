import fs from 'node:fs/promises';
import path from 'node:path';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const root = process.env.HEALTHCARE_WORKSPACE_ROOT;
if (!root) throw new Error('HEALTHCARE_WORKSPACE_ROOT required');
const source = path.join(root, 'healthcare_model_correction_20261031');
const outputDir = path.join(root, 'outputs', 'healthcare_polish_v3');
await fs.mkdir(outputDir, {recursive:true});
const control = JSON.parse(await fs.readFile(path.join(source,'Model_Correction_Reconciliation.json'),'utf8'));
const p = control.input_parameters;

const c = {
  ink:'#152A37', navy:'#102935', navy2:'#183D49', teal:'#128C88', mint:'#E7F5F1',
  gold:'#BD8E42', sand:'#FFF5DF', paper:'#FFFFFF', bg:'#F3F6F6', line:'#DDE6E8',
  muted:'#637784', red:'#A64341', softRed:'#FFF0EB', purple:'#665D92', source:'#2C654B',
  blue:'#235CA8', lightBlue:'#EEF5FF', white:'#FFFFFF'
};
const wb=Workbook.create();
const dashboard=wb.worksheets.add('Overview');
const summary=wb.worksheets.add('Summary');
const inputs=wb.worksheets.add('Inputs');
const annual=wb.worksheets.add('Annual 2025-2124');
const audit=wb.worksheets.add('Audit Notes');

const font='Arial';
function paint(sh,ref,fill,{color=c.ink,size=10,bold=false,italic=false,align='left',vertical='center',wrap=false}={}){
  const r=sh.getRange(ref);
  r.format.fill=fill;
  r.format.font={name:font,size,bold,italic,color};
  r.format.horizontalAlignment=align;
  r.format.verticalAlignment=vertical;
  r.format.wrapText=wrap;
  return r;
}
function txt(sh,cell,value){sh.getRange(cell).values=[[value]];}
function formula(sh,cell,value){sh.getRange(cell).formulas=[[value]];}
function section(sh,range){paint(sh,range,c.navy2,{color:c.white,bold:true,size:10});}
function header(sh,range){paint(sh,range,c.navy,{color:c.white,bold:true,size:10,align:'center'});}
function borderBottom(sh,range,color=c.line){sh.getRange(range).format.borders={bottom:{style:'thin',color}};}
for (const sh of [dashboard,summary,inputs,annual,audit]) sh.showGridLines=false;
dashboard.tabColor=c.navy;
summary.tabColor=c.teal;
inputs.tabColor=c.gold;
audit.tabColor=c.muted;

// Workbook controls match the source-driven v2 cell addresses exactly.
inputs.getRange('A1:C1').values=[['MODEL INPUT','VALUE','PROVENANCE / RULE']];
header(inputs,'A1:C1');
const specs=[
 ['2024 national healthcare expenditure ($B)',p.corrected_anchor_B,'Project exact anchor; CMS historical NHE rounds to $5,278.6B'],
 ['2024 personal healthcare ($B)',p.corrected_personal_care_B,'Informational only; not added to baseline'],
 ['Baseline growth 2025-2034',p.growth_first,'Historical Step48 Assumptions B10'],
 ['Baseline growth 2035-2054',p.growth_later,'Historical Step48 Assumptions B11'],
 ['Rollout period (years)',p.phasein_years,'Historical Step48 Assumptions B19'],
 ['Added ongoing care rate',p.ongoing_care,'Historical Step48 Assumptions B14'],
 ['Added capacity rate',p.capacity_spending,'Historical Step48 Assumptions B15'],
 ['Max catch-up delivery rate',p.delivery_cap,'Historical Step48 Assumptions B18'],
 ['Long-run growth 2055-2124',p.after2054_growth,'Original 100-year Drivers B3'],
 ['Limited price credit ($B)',p.price_base_B,'Original 100-year Drivers B7'],
 ['Insurer nonmedical expense pool ($B)',p.admin_pool_B,'Original 100-year Drivers B8'],
 ['Net admin saving share',p.net_admin_fraction,'Original 100-year Drivers B9'],
 ['Provider support in deeper cases ($B)',p.deep_provider_support_B,'Original 100-year Drivers B10'],
 ['JAMA price case ($B)',p.JAMA_price_B,'Original 100-year Drivers B11'],
 ['Milliman + RAND price case ($B)',p.Milliman_RAND_price_B,'Original 100-year Drivers B12'],
 ['Milliman + HCCI price case ($B)',p.Milliman_HCCI_price_B,'Original 100-year Drivers B13'],
 ['RAND + Milliman price case ($B)',p.RAND_Milliman_price_B,'Original 100-year Drivers B14'],
 ['Inflation used in present value',p.inflation,'Original 100-year Drivers B15'],
 ['Real discount rate',p.real_discount,'Original 100-year Drivers B16'],
];
inputs.getRange('A2:C20').values=specs;
inputs.getRange('E1:F1').values=[['YEAR','NEW BACKLOG REQUEST']];
header(inputs,'E1:F1');
inputs.getRange('E2:F31').values=p.catchup_request_share.map((v,i)=>[2025+i,v]);
paint(inputs,'A2:A20',c.paper,{size:10});
paint(inputs,'B2:B20',c.sand,{color:c.blue,bold:true,align:'right'});
paint(inputs,'C2:C20',c.paper,{color:c.muted,size:9});
paint(inputs,'E2:E31',c.bg,{align:'center'});
paint(inputs,'F2:F31',c.sand,{color:c.blue,align:'right'});
inputs.getRange('B4:B5').setNumberFormat('0.0%');
inputs.getRange('B7:B10').setNumberFormat('0.0%');
inputs.getRange('B13').setNumberFormat('0.0%');
inputs.getRange('B19:B20').setNumberFormat('0.0%');
inputs.getRange('F2:F31').setNumberFormat('0.0%');
inputs.getRange('B2:B3').setNumberFormat('#,##0.000');
inputs.getRange('B11:B12').setNumberFormat('#,##0.000');
inputs.getRange('B14:B18').setNumberFormat('#,##0.000');
inputs.getRange('A:A').format.columnWidth=44;
inputs.getRange('B:B').format.columnWidth=17;
inputs.getRange('C:C').format.columnWidth=76;
inputs.getRange('D:D').format.columnWidth=4;
inputs.getRange('E:E').format.columnWidth=14;
inputs.getRange('F:F').format.columnWidth=20;
inputs.getRange('A2:F31').format.rowHeight=22;
inputs.freezePanes.freezeRows(1);
borderBottom(inputs,'A20:C20',c.gold);

// Annual formulas replicate v2 source generation and preserve editable inputs.
const cols=[
'Year','Model year','Growth','Rollout','A - baseline ($B)','New requests ($B)',
'Queue in ($B)','Waiting ($B)','Delivery ceiling ($B)','Catch-up delivered ($B)',
'Queue out ($B)','New ongoing care ($B)','Capacity addition ($B)','B0 - gross universal ($B)',
'Exposure factor','Price credit ($B)','Admin credit ($B)','B - universal ($B)',
'C - price case ($B)','D - combined ($B)','D minus A ($B)','Cumulative D-A ($B)',
'JAMA case D-A ($B)','Milliman+RAND D-A ($B)','Milliman+HCCI D-A ($B)',
'RAND+Milliman D-A ($B)','PV central ($B)','PV JAMA ($B)','PV M+R ($B)','PV M+H ($B)','PV R+M ($B)'];
annual.getRange('A1:AE1').values=[cols];
for(const [range,fill] of [['A1:B1',c.navy],['C1:D1',c.navy2],['E1:N1','#255365'],['O1:Q1',c.teal],['R1:V1',c.gold],['W1:AE1',c.purple]])
  paint(annual,range,fill,{color:c.white,bold:true,size:9,align:'center',wrap:true});
annual.getRange('A1:AE1').format.rowHeight=48;
annual.getRange('A:A').format.columnWidth=11;
annual.getRange('B:B').format.columnWidth=12;
annual.getRange('C:D').format.columnWidth=12;
annual.getRange('E:AE').format.columnWidth=18;
annual.getRange('E:N').format.columnWidth=20;
annual.getRange('W:AE').format.columnWidth=21;
annual.freezePanes.freezeRows(1);
const formulaRows=[];
for(let i=0;i<100;i++){
 const ex=i+2,prev=ex-1,year=2025+i;
 const fs=[
  year<=2034?'=Inputs!$B$4':year<=2054?'=Inputs!$B$5':'=Inputs!$B$10',
  `=MIN(1,B${ex}/Inputs!$B$6)`,
  i===0?`=Inputs!$B$2*(1+C${ex})`:`=E${prev}*(1+C${ex})`,
  i<30?`=E${ex}*Inputs!F${ex}`:'=0',
  i===0||i>=30?'=0':`=K${prev}`,
  i<30?`=F${ex}+G${ex}`:'=0',
  i<30?`=E${ex}*Inputs!$B$9*D${ex}`:'=0',
  i<30?`=MIN(H${ex},I${ex})`:'=0',
  i<30?`=MAX(0,H${ex}-J${ex})`:'=0',
  `=E${ex}*Inputs!$B$7*D${ex}`,
  `=E${ex}*Inputs!$B$8*D${ex}`,
  `=E${ex}+L${ex}+J${ex}+M${ex}`,
  `=E${ex}*D${ex}/Inputs!$B$2`,
  `=O${ex}*Inputs!$B$11`,
  `=O${ex}*Inputs!$B$12*Inputs!$B$13`,
  `=N${ex}-Q${ex}`,
  `=E${ex}-P${ex}`,
  `=N${ex}-P${ex}-Q${ex}`,
  `=T${ex}-E${ex}`,
  i===0?`=U${ex}`:`=V${prev}+U${ex}`,
  ...[15,16,17,18].map(j=>`=U${ex}-O${ex}*(Inputs!$B$${j}-Inputs!$B$11-Inputs!$B$14)`),
  ...['U','W','X','Y','Z'].map(col=>`=${col}${ex}/((1+Inputs!$B$19)*(1+Inputs!$B$20))^(B${ex}-1)`)
 ];
 formulaRows.push(fs);
}
annual.getRange('A2:B101').values=Array.from({length:100},(_,i)=>[2025+i,i+1]);
annual.getRange('C2:AE101').formulas=formulaRows;
paint(annual,'A2:B101',c.bg,{color:c.ink,align:'center',size:9});
paint(annual,'C2:AE101',c.paper,{color:c.ink,size:9,align:'right'});
for(let i=0;i<100;i+=2){paint(annual,`C${i+2}:AE${i+2}`,c.bg,{color:c.ink,size:9,align:'right'});}
annual.getRange('C2:D101').setNumberFormat('0.0%');
annual.getRange('O2:O101').setNumberFormat('0.000');
annual.getRange('E2:N101').setNumberFormat('#,##0.0;(#,##0.0);-');
annual.getRange('P2:AE101').setNumberFormat('#,##0.0;(#,##0.0);-');
annual.getRange('E2:E101').format.font={name:font,size:9,color:c.source};
annual.getRange('P2:Q101').format.font={name:font,size:9,color:c.source};
annual.getRange('U2:U101').format.font={name:font,size:9,color:c.red,bold:true};
annual.getRange('A2:AE101').format.rowHeight=19;
for(let i=0;i<100;i+=10)borderBottom(annual,`A${i+11}:AE${i+11}`,c.gold);

// Summary reads the annual build and owns no new scenario assumptions.
summary.getRange('A1:I1').values=[['YEARS','A - baseline','B0 - universal gross','B - universal','C - price case','D - combined','D minus A','Price credit','Admin credit']];
header(summary,'A1:I1');
summary.getRange('A2:A6').values=[[5],[10],[20],[30],[100]];
const map=[['E',1],['N',2],['R',3],['S',4],['T',5],['U',6],['P',7],['Q',8]];
for(let i=0;i<5;i++){
 const end=[6,11,21,31,101][i],row=i+2;
 for(const [col,j] of map){const dcol=String.fromCharCode(65+j);
  formula(summary,`${dcol}${row}`,`=SUM('Annual 2025-2124'!${col}2:${col}${end})/1000`);}
}
paint(summary,'A2:A6',c.bg,{bold:true,align:'center'});
paint(summary,'B2:F6',c.paper,{align:'right'});
paint(summary,'G2:G6',c.softRed,{color:c.red,bold:true,align:'right'});
paint(summary,'H2:I6',c.mint,{color:c.source,align:'right'});
summary.getRange('B2:I6').setNumberFormat('#,##0.000;(#,##0.000);-');
summary.getRange('A1:I6').format.rowHeight=26;
summary.getRange('A:A').format.columnWidth=12;
summary.getRange('B:I').format.columnWidth=23;
summary.getRange('K1').values=[['SCENARIO NOTES']];
paint(summary,'K1:M1',c.navy2,{color:c.white,bold:true});
summary.getRange('K2').values=[['A = unchanged financing / no reform']];
summary.getRange('K3').values=[['B0 = expanded care before credited savings']];
summary.getRange('K4').values=[['B = B0 less insurer administration credit']];
summary.getRange('K5').values=[['C = A less limited price credit']];
summary.getRange('K6').values=[['D = B0 less both credits']];
summary.getRange('K2:K6').format.font={name:font,size:10,color:c.muted};
summary.getRange('K:K').format.columnWidth=50;
summary.getRange('A9:C9').values=[['PRICE CASE','30-YEAR D-A ($T)','100-YEAR D-A ($T)']];
header(summary,'A9:C9');
const cases=[['JAMA','W'],['Milliman + RAND','X'],['Milliman + HCCI','Y'],['RAND + Milliman','Z']];
for(let i=0;i<cases.length;i++){
 const row=10+i;txt(summary,`A${row}`,cases[i][0]);
 formula(summary,`B${row}`,`=SUM('Annual 2025-2124'!${cases[i][1]}2:${cases[i][1]}31)/1000`);
 formula(summary,`C${row}`,`=SUM('Annual 2025-2124'!${cases[i][1]}2:${cases[i][1]}101)/1000`);
}
paint(summary,'A10:A13',c.bg);paint(summary,'B10:C13',c.paper,{align:'right'});
summary.getRange('B10:C13').setNumberFormat('#,##0.000;(#,##0.000);-');
summary.getRange('A9:C13').format.rowHeight=25;
txt(summary,'A16','Price cases are conditional sensitivities; they are not observed savings.');
txt(summary,'A17','All figures are nominal trillions; scenario comparisons are total national expenditure, not a federal budget.');
paint(summary,'A16:I17',c.paper,{color:c.muted,italic:true,size:10});

// The reader-facing opening sheet: selected output, clear comparison, real limitations.
dashboard.getRange('A:A').format.columnWidth=3;
dashboard.getRange('B:B').format.columnWidth=24;
dashboard.getRange('C:C').format.columnWidth=20;
dashboard.getRange('D:E').format.columnWidth=18;
dashboard.getRange('F:F').format.columnWidth=21;
dashboard.getRange('G:G').format.columnWidth=4;
dashboard.getRange('H:P').format.columnWidth=12;
dashboard.getRange('B2:P44').format.rowHeight=23;
txt(dashboard,'B2','DARK STAR CONSULTING GROUP  /  HEALTHCARE THOUGHT EXPERIMENT');
paint(dashboard,'B2:P2',c.paper,{color:c.teal,size:9,bold:true});
txt(dashboard,'B4','Universal coverage. Calculated.');
paint(dashboard,'B4:F4',c.paper,{color:c.ink,size:20,bold:true});
txt(dashboard,'B5','Source-driven national expenditure model  |  2025-2054 central case');
paint(dashboard,'B5:F5',c.paper,{color:c.muted,size:10});
borderBottom(dashboard,'B6:P6',c.gold);
txt(dashboard,'B8','30-YEAR NET EXPENDITURE CHANGE');
paint(dashboard,'B8:F8',c.paper,{color:c.teal,size:10,bold:true});
formula(dashboard,'B9','=Summary!G5');
dashboard.getRange('B9').setNumberFormat('+#,##0.000" T";(#,##0.000" T");-');
paint(dashboard,'B9:D10',c.paper,{color:c.red,size:24,bold:true});
txt(dashboard,'B11','More spending in the limited-price case; not a projected saving.');
paint(dashboard,'B11:F11',c.paper,{color:c.muted,size:10});
for(const [label,cell,fm] of [
 ['2024 NHE anchor ($B)','B14','=Inputs!B2'],
 ['Expansion before credits ($T)','D14','=Summary!C5-Summary!B5'],
 ['Credits included ($T)','F14','=Summary!C5-Summary!F5']]){
  const col=cell[0],row=Number(cell.slice(1));
  txt(dashboard,`${col}${row-1}`,label);paint(dashboard,`${col}${row-1}`,c.paper,{size:9,color:c.muted});
  formula(dashboard,cell,fm);paint(dashboard,cell,c.paper,{size:15,bold:true,color:c.ink});
  dashboard.getRange(cell).setNumberFormat('#,##0.000');
}
dashboard.getRange('B17:F17').values=[['SCENARIO','DESCRIPTION',null,null,'30-YEAR $T']];
section(dashboard,'B17:F17');
const scenarios=[
 ['A','Status quo','=Summary!B5','=Summary!B5-Summary!B5'],
 ['B','Expanded coverage; admin credit','=Summary!D5','=Summary!D5-Summary!B5'],
 ['C','Existing coverage; price credit','=Summary!E5','=Summary!E5-Summary!B5'],
 ['D','Expanded coverage; both credits','=Summary!F5','=Summary!F5-Summary!B5']
];
for(let i=0;i<4;i++){
 const row=18+i;
 txt(dashboard,`B${row}`,scenarios[i][0]);
 txt(dashboard,`C${row}`,scenarios[i][1]);
 formula(dashboard,`F${row}`,scenarios[i][2]);
 formula(dashboard,`E${row}`,scenarios[i][3]);
 paint(dashboard,`B${row}:F${row}`,i%2===0?c.bg:c.paper,{size:10});
 paint(dashboard,`F${row}`,i===3?c.sand:(i%2===0?c.bg:c.paper),{color:c.ink,align:'right',bold:i===3});
 paint(dashboard,`E${row}`,i===3?c.softRed:(i%2===0?c.bg:c.paper),{color:i===3?c.red:c.muted,align:'right'});
}
dashboard.getRange('E17').values=[['VS A ($T)']];
dashboard.getRange('E18:F21').setNumberFormat('#,##0.000;(#,##0.000);-');
dashboard.getRange('C:C').format.columnWidth=32;
txt(dashboard,'B24','30-YEAR COST COMPONENTS');
section(dashboard,'B24:F24');
dashboard.getRange('B25:C25').values=[['Component','Amount ($T)']];
for(const [row,label,fm] of [
 [26,'Expanded care','=Summary!C5-Summary!B5'],
 [27,'Price credit','=-Summary!H5'],
 [28,'Administration credit','=-Summary!I5'],
 [29,'Net additional','=Summary!G5']]){
  txt(dashboard,`B${row}`,label);formula(dashboard,`C${row}`,fm);
  paint(dashboard,`B${row}:C${row}`,row===29?c.sand:c.paper,{bold:row===29,color:c.ink});
}
dashboard.getRange('C26:C29').setNumberFormat('+#,##0.000;(#,##0.000);-');
txt(dashboard,'B32','PERIOD COMPARISON');section(dashboard,'B32:F32');
dashboard.getRange('B33:C33').values=[['Horizon (years)','Net additional ($T)']];
for(let i=0;i<4;i++){
 const r=34+i;formula(dashboard,`B${r}`,`=Summary!A${i+2}`);formula(dashboard,`C${r}`,`=Summary!G${i+2}`);
}
paint(dashboard,'B33:C33',c.navy2,{color:c.white,bold:true,align:'center'});
paint(dashboard,'B34:C37',c.bg,{color:c.ink});
dashboard.getRange('C34:C37').setNumberFormat('#,##0.000;(#,##0.000);-');
txt(dashboard,'B40','RESEARCH BOUNDARY');
paint(dashboard,'B40:F40',c.paper,{color:c.teal,bold:true,size:10});
txt(dashboard,'B41','No additional credit was booked for paperwork reduction or public purchasing leverage.');
txt(dashboard,'B42','Provider-safe rates, staffing, transition cash and clinical value still require testing.');
paint(dashboard,'B41:F42',c.paper,{color:c.muted,size:9});
// Charts stay on the right-hand side and use linked source cells.
dashboard.getRange('R25:S25').values=[['Component','Magnitude ($T)']];
for (const [row,label] of [[26,'Expanded care'],[27,'Price credit'],[28,'Admin credit'],[29,'Net additional']]){
  txt(dashboard,`R${row}`,label);
  formula(dashboard,`S${row}`,`=ABS(C${row})`);
}
const bridge=dashboard.charts.add('bar',dashboard.getRange('R25:S29'));
bridge.title='30-year cost components, magnitude ($T)';
bridge.titleTextStyle.typeface=font;bridge.titleTextStyle.fontSize=13;
bridge.hasLegend=false;
bridge.yAxis={numberFormatCode:'0.0',numberFormatSourceLinked:false,textStyle:{typeface:font,fontSize:10}};
bridge.xAxis={axisType:'textAxis',textStyle:{typeface:font,fontSize:10}};
bridge.setPosition('H8','P25');
const trend=dashboard.charts.add('line',dashboard.getRange('B33:C37'));
trend.title='Cumulative additional spending ($T)';
trend.titleTextStyle.typeface=font;trend.titleTextStyle.fontSize=13;
trend.hasLegend=false;
trend.xAxis={axisType:'textAxis',textStyle:{typeface:font,fontSize:10}};
trend.yAxis={numberFormatCode:'0.0',numberFormatSourceLinked:false,textStyle:{typeface:font,fontSize:10}};
trend.setPosition('H27','P43');

// Documentation remains concise, specific, and separate from business results.
audit.getRange('A1:B1').values=[['SOURCE RECOVERY / METHOD','STATUS AND EXPLANATION']];
header(audit,'A1:B1');
const notes=[
 ['30-year B0 generator','Recovered from Step48 workbook, Annual model row 21, with Assumptions B7/B10/B11/B14/B15/B18/B19/B25:AE25.'],
 ['Original B0 reconciliation','$373.561245309883T unadjusted expansion, matching locked $373.561245310T control.'],
 ['2024 baseline correction','NHE working $5,278.600B corrected to original source precision $5,278.588B.'],
 ['2024 personal healthcare','Informational $4,510.200B corrected to $4,510.222B; not separately booked.'],
 ['Original total reproduced','Prior 30-year combined scenario D-A $15.681257965842T.'],
 ['New exact-anchor total','Corrected 30-year combined scenario D-A $15.681222317167T.'],
 ['Method preserved','Same 2025-2054 catch-up queue and 2055-2124 4% nominal extension.'],
 ['Unbooked hypotheses','No newly quantified savings for paperwork, monopoly purchasing, fraud, medical debt, or early detection.'],
 ['Review limitations','Provider payments, staffed capacity, transition cash, and measured outcomes remain unvalidated.'],
 ['Scope','Nominal national healthcare expenditures; not a federal revenue or financing forecast.'],
 ['Original sources','Historical Step48 and 100-year workbooks remain unchanged in the accompanying package.'],
 ['CMS source','https://www.cms.gov/data-research/statistics-trends-and-reports/national-health-expenditure-data/historical'],
];
audit.getRange('A2:B13').values=notes;
paint(audit,'A2:A13',c.bg,{bold:true});
paint(audit,'B2:B13',c.paper,{color:c.muted,size:10});
audit.getRange('A:A').format.columnWidth=31;
audit.getRange('B:B').format.columnWidth=116;
audit.getRange('A1:B13').format.rowHeight=27;

// Recalculate all formulas. Verify the numerical controls before export.
wb.recalculate();
const check=await wb.inspect({kind:'table',range:'Summary!A1:I6',include:'values,formulas',tableMaxRows:6,tableMaxCols:9,maxChars:3000});
console.log('SUMMARY_CHECK',check.ndjson.slice(0,3000));
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:80},summary:'formula error scan',maxChars:1600});
console.log('ERROR_CHECK',errors.ndjson.slice(0,1600));

for(const [sheetName,range,file] of [
 ['Overview','A1:P45','preview_overview.png'],
 ['Summary','A1:M19','preview_summary.png'],
 ['Inputs','A1:F22','preview_inputs.png'],
 ['Annual 2025-2124','A1:O12','preview_annual.png'],
 ['Audit Notes','A1:B13','preview_audit.png']]){
  try{
    const preview=await wb.render({sheetName,range,scale:1.4,format:'png'});
    await fs.writeFile(path.join(outputDir,file),new Uint8Array(await preview.arrayBuffer()));
    console.log('RENDERED',file);
  }catch(err){console.warn('RENDER_ERROR',sheetName,String(err).slice(0,300));}
}
const target=path.join(outputDir,'Universal_Healthcare_Reviewer_Model_v3.xlsx');
const xlsx=await SpreadsheetFile.exportXlsx(wb);
await xlsx.save(target);
console.log('EXPORTED',target);
