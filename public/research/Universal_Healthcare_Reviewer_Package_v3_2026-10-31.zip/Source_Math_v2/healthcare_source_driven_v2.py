#!/usr/bin/env python3
"""Version 2: source-driven 30-year B0 generator and corrected 2024 baseline.

Both historical source workbooks must be in ./sources. Do not alter them.
The correction is a *conditional* model, not an empirical healthcare forecast.
"""
from __future__ import annotations

import csv
import hashlib
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from statistics import mean

import openpyxl
import xlsxwriter
from xlsxwriter.utility import xl_rowcol_to_cell

HERE = Path(__file__).resolve().parent
SOURCES = HERE / "sources"
STEP48 = SOURCES / "Universal_Healthcare_Step48_Thirty_Year_Integrated_Scenario_Model.xlsx"
CENTURY = SOURCES / "Universal_Healthcare_100_Year_Financial_Model_2025-2124.xlsx"
BASE_EXACT_B = 5278.588
PHC_EXACT_B = 4510.222

@dataclass
class Year:
    year: int
    model_year: int
    growth: float
    rollout: float
    A_B: float
    requests_B: float
    queue_in_B: float
    waiting_B: float
    delivery_limit_B: float
    delivered_B: float
    queue_out_B: float
    recurring_B: float
    capacity_B: float
    B0_B: float
    weighted_factor: float
    price_B: float
    admin_B: float
    B_B: float
    C_B: float
    D_B: float
    D_minus_A_B: float
    cumulative_D_minus_A_B: float
    JAMA_diff_B: float
    Milliman_RAND_diff_B: float
    Milliman_HCCI_diff_B: float
    RAND_Milliman_diff_B: float
    PV_central_B: float
    PV_JAMA_B: float
    PV_Milliman_RAND_B: float
    PV_Milliman_HCCI_B: float
    PV_RAND_Milliman_B: float

def load_sources():
    old = openpyxl.load_workbook(STEP48, read_only=False, data_only=True)
    companion = openpyxl.load_workbook(CENTURY, read_only=False, data_only=True)
    ass = old["Assumptions"]
    drv = companion["Drivers"]
    assert ass["B4"].value == 1, "Source clinical cash offset was not zero"
    assert abs(drv["B6"].value - BASE_EXACT_B) < 1e-7
    assert abs(ass["B7"].value - 5278.6) < 1e-7
    assert abs(ass["B8"].value - 4510.2) < 1e-7
    inputs = {
        "old_anchor_B":float(ass["B7"].value),
        "old_personal_care_B":float(ass["B8"].value),
        "corrected_anchor_B":BASE_EXACT_B,
        "corrected_personal_care_B":PHC_EXACT_B,
        "growth_first":float(ass["B10"].value),
        "growth_later":float(ass["B11"].value),
        "phasein_years":int(ass["B19"].value),
        "ongoing_care":float(ass["B14"].value),
        "capacity_spending":float(ass["B15"].value),
        "delivery_cap":float(ass["B18"].value),
        "catchup_request_share":[float(ass.cell(25,i).value) for i in range(2,32)],
        "after2054_growth":float(drv["B3"].value),
        "price_base_B":float(drv["B7"].value),
        "admin_pool_B":float(drv["B8"].value),
        "net_admin_fraction":float(drv["B9"].value),
        "deep_provider_support_B":float(drv["B10"].value),
        "JAMA_price_B":float(drv["B11"].value),
        "Milliman_RAND_price_B":float(drv["B12"].value),
        "Milliman_HCCI_price_B":float(drv["B13"].value),
        "RAND_Milliman_price_B":float(drv["B14"].value),
        "inflation":float(drv["B15"].value),
        "real_discount":float(drv["B16"].value),
    }
    assert inputs["catchup_request_share"][:10] == [.01,.02,.03,.04,.05,.05,.04,.03,.02,.01]
    assert all(v==0 for v in inputs["catchup_request_share"][10:])
    original_source = old["Annual model"]
    original = []
    for i in range(30):
        c=i+2
        original.append({
            "year":int(original_source.cell(3,c).value),
            "A_B":float(original_source.cell(9,c).value),
            "requests_B":float(original_source.cell(12,c).value),
            "delivered_B":float(original_source.cell(16,c).value),
            "queue_out_B":float(original_source.cell(17,c).value),
            "B0_B":float(original_source.cell(21,c).value),
        })
    old.close()
    companion.close()
    return inputs, original

def generate(anchor_B:float, inputs:dict)->list[Year]:
    a_prev = anchor_B
    queue = cumulative = 0.0
    result=[]
    for i in range(100):
        year=2025+i
        growth=(inputs["growth_first"] if year<=2034 else
                inputs["growth_later"] if year<=2054 else
                inputs["after2054_growth"])
        a=a_prev*(1+growth)
        rollout=min(1.0,(i+1)/inputs["phasein_years"])
        recurring=a*inputs["ongoing_care"]*rollout
        capacity=a*inputs["capacity_spending"]*rollout
        if year<=2054:
            requests=a*inputs["catchup_request_share"][i]
            queue_in=queue
            waiting=queue_in+requests
            max_delivery=a*inputs["delivery_cap"]*rollout
            delivered=min(waiting,max_delivery)
            queue=max(0,waiting-delivered)
        else:
            requests=queue_in=waiting=max_delivery=delivered=0.0
            queue=0.0
        b0=a+recurring+delivered+capacity
        w=a*rollout/BASE_EXACT_B
        price=w*inputs["price_base_B"]
        admin=w*inputs["admin_pool_B"]*inputs["net_admin_fraction"]
        b=b0-admin
        c=a-price
        d=b0-price-admin
        delta=d-a
        cumulative+=delta
        def deeper(price_B):
            return delta-w*(price_B-inputs["price_base_B"]-inputs["deep_provider_support_B"])
        jama=deeper(inputs["JAMA_price_B"])
        mr=deeper(inputs["Milliman_RAND_price_B"])
        mh=deeper(inputs["Milliman_HCCI_price_B"])
        rm=deeper(inputs["RAND_Milliman_price_B"])
        discount=((1+inputs["inflation"])*(1+inputs["real_discount"]))**i
        result.append(Year(year,i+1,growth,rollout,a,requests,queue_in,waiting,max_delivery,delivered,queue,
            recurring,capacity,b0,w,price,admin,b,c,d,delta,cumulative,
            jama,mr,mh,rm,delta/discount,jama/discount,mr/discount,mh/discount,rm/discount))
        a_prev=a
    return result

def sum_years(rows:list[Year],attribute:str,n:int)->float:
    return sum(getattr(r,attribute) for r in rows[:n])

def verify_old_source(legacy:list[Year],source:list[dict])->dict:
    errs={}
    for key in ("A_B","requests_B","delivered_B","queue_out_B","B0_B"):
        ds=[abs(getattr(a,key)-b[key]) for a,b in zip(legacy[:30],source)]
        errs[key]={"max_abs_B":max(ds),"mean_abs_B":mean(ds)}
        if max(ds)>1e-6:
            raise AssertionError(f"Original B0 generator failed source comparison: {key} max {max(ds)} $B")
    # Proves source lineage, rather than fitting B0 to the final printed scenario B.
    s=sum_years(legacy,"B0_B",30)/1000
    if abs(s-373.561245310)>0.000000001:
        raise AssertionError(f"Legacy B0 control does not reconcile: {s} $T")
    return errs

def compare_original_century(legacy:list[Year])->dict:
    """Identify six-decimal publication rounding; do not calibrate against it."""
    book=openpyxl.load_workbook(CENTURY,data_only=True,read_only=False)
    sheet=book["Annual"]
    out={}
    for attribute,column in [("A_B",4),("B0_B",5),("B_B",9),("C_B",10),
                             ("D_B",11),("D_minus_A_B",12)]:
        original=[float(sheet.cell(i+6,column).value)*1000 for i in range(100)]
        differences=[getattr(legacy[i],attribute)-original[i] for i in range(100)]
        out[attribute]={"max_abs_B":max(abs(v) for v in differences),
                        "100yr_sum_difference_B":sum(differences)}
        if max(abs(v) for v in differences)>0.002:
            raise AssertionError(f"100-year legacy source differs by more than $2 million/year: {attribute}")
    book.close()
    return out

def summary(rows:list[Year])->dict:
    return {str(n):{label:sum_years(rows,attribute,n)/1000 for label,attribute in [
        ("A_T","A_B"),("B0_T","B0_B"),("B_T","B_B"),("C_T","C_B"),("D_T","D_B"),
        ("D_minus_A_T","D_minus_A_B"),("price_credit_T","price_B"),("admin_credit_T","admin_B"),
        ("JAMA_D_minus_A_T","JAMA_diff_B"),("Milliman_RAND_D_minus_A_T","Milliman_RAND_diff_B"),
        ("Milliman_HCCI_D_minus_A_T","Milliman_HCCI_diff_B"),("RAND_Milliman_D_minus_A_T","RAND_Milliman_diff_B")]}
        for n in (5,10,20,30,100)}

def write_csv(rows:list[Year],path:Path):
    with path.open("w",newline="",encoding="utf-8") as f:
        writer=csv.DictWriter(f,fieldnames=list(Year.__dataclass_fields__))
        writer.writeheader()
        writer.writerows(asdict(r) for r in rows)

def write_excel(corrected:list[Year],legacy:list[Year],inputs:dict,out:Path):
    book=xlsxwriter.Workbook(str(out))
    book.set_properties({"title":"Healthcare Source-Driven Model v2","comments":"Corrected CMS 2024 anchor and recovered Step48 30-year B0 generator"})
    inp=book.add_worksheet("Inputs")
    ann=book.add_worksheet("Annual 2025-2124")
    sums=book.add_worksheet("Summary")
    proof=book.add_worksheet("Audit Notes")
    header=book.add_format({"bold":True,"bg_color":"#14314A","font_color":"white"})
    fmt=book.add_format({"num_format":"#,##0.000000"})
    pct=book.add_format({"num_format":"0.00%"})
    inp.freeze_panes(1,0)
    inp.set_column("A:A",52)
    inp.set_column("B:B",22)
    inp.set_column("C:C",78)
    inp.set_column("E:E",14)
    inp.set_column("F:F",18)
    inp.write_row(0,0,["Parameter","Value","Source and status"],header)
    specs=[
        ("2024 NHE ($B)",inputs["corrected_anchor_B"],"CMS 2024 exact source / original 100-year Drivers B6"),
        ("2024 personal healthcare ($B)",inputs["corrected_personal_care_B"],"CMS 2024 exact figure; presentation only"),
        ("Growth 2025–2034",inputs["growth_first"],"Original Step48 Assumptions B10"),
        ("Growth 2035–2054",inputs["growth_later"],"Original Step48 Assumptions B11"),
        ("Rollout years",inputs["phasein_years"],"Original Step48 Assumptions B19"),
        ("Recurring new care",inputs["ongoing_care"],"Original Step48 Assumptions B14"),
        ("Added capacity spending",inputs["capacity_spending"],"Original Step48 Assumptions B15"),
        ("Maximum deferred delivery",inputs["delivery_cap"],"Original Step48 Assumptions B18"),
        ("Nominal growth 2055–2124",inputs["after2054_growth"],"Original 100-year Drivers B3"),
        ("Limited five-cell price credit ($B)",inputs["price_base_B"],"Original 100-year Drivers B7"),
        ("Private insurer nonmedical pool ($B)",inputs["admin_pool_B"],"Original 100-year Drivers B8"),
        ("Net insurer administrative saving",inputs["net_admin_fraction"],"Original 100-year Drivers B9"),
        ("Deeper-price provider support ($B)",inputs["deep_provider_support_B"],"Original 100-year Drivers B10"),
        ("JAMA deep-price credit ($B)",inputs["JAMA_price_B"],"Original 100-year Drivers B11"),
        ("Milliman + RAND deep-price credit ($B)",inputs["Milliman_RAND_price_B"],"Original 100-year Drivers B12"),
        ("Milliman + HCCI deep-price credit ($B)",inputs["Milliman_HCCI_price_B"],"Original 100-year Drivers B13"),
        ("RAND + Milliman deep-price credit ($B)",inputs["RAND_Milliman_price_B"],"Original 100-year Drivers B14"),
        ("Inflation rate for PV",inputs["inflation"],"Original 100-year Drivers B15"),
        ("Real discount rate for PV",inputs["real_discount"],"Original 100-year Drivers B16"),
    ]
    for row,(label,value,source) in enumerate(specs,start=1):
        inp.write(row,0,label);inp.write_number(row,1,value);inp.write(row,2,source)
    inp.write_row(0,4,["Year","Catch-up request share"],header)
    for i,request in enumerate(inputs["catchup_request_share"],start=1):
        inp.write_number(i,4,2024+i);inp.write_number(i,5,request,pct)
    # Excel coordinates corresponding to specs: baseline B2, PHC B3, growth B4/B5,
    # rollout B6, recurring B7, capacity B8, delivery B9, long growth B10,
    # price B11, insurance B12, net fraction B13, support B14,
    # alternate price cases B15/B16/B17/B18, inflation B19 and real discount B20.
    headings=[
        "Year","Model year","Growth","Rollout","A baseline $B","New catch-up $B",
        "Carry-in queue $B","Waiting queue $B","Delivery ceiling $B","Delivered catch-up $B",
        "Carry-out queue $B","Recurring new care $B","Capacity investment $B","B0 unadjusted $B",
        "Exposure factor","Price credit $B","Admin credit $B","B universal $B",
        "C regulated $B","D combined $B","D-A $B","Cumulative D-A $B",
        "JAMA D-A $B","Milliman+RAND D-A $B","Milliman+HCCI D-A $B",
        "RAND+Milliman D-A $B","PV central $B","PV JAMA $B",
        "PV M+R $B","PV M+H $B","PV RAND $B",
    ]
    ann.write_row(0,0,headings,header)
    ann.freeze_panes(1,4)
    ann.set_column(0,1,13);ann.set_column(2,3,12);ann.set_column(4,30,19,fmt)
    def f(row:int,col:int,expression:str,value:float):
        ann.write_formula(row,col,expression,fmt,value)
    for i,r in enumerate(corrected):
        row=i+1
        ex=row+1
        prev=ex-1
        ann.write_number(row,0,r.year)
        ann.write_number(row,1,r.model_year)
        f(row,2, "=Inputs!$B$4" if r.year<=2034 else "=Inputs!$B$5" if r.year<=2054 else "=Inputs!$B$10",r.growth)
        f(row,3,f"=MIN(1,B{ex}/Inputs!$B$6)",r.rollout)
        f(row,4,f"=Inputs!$B$2*(1+C{ex})" if i==0 else f"=E{prev}*(1+C{ex})",r.A_B)
        f(row,5,f"=E{ex}*Inputs!F{2+i}" if i<30 else "=0",r.requests_B)
        f(row,6,"=0" if i==0 or i>=30 else f"=K{prev}",r.queue_in_B)
        f(row,7,f"=F{ex}+G{ex}" if i<30 else "=0",r.waiting_B)
        f(row,8,f"=E{ex}*Inputs!$B$9*D{ex}" if i<30 else "=0",r.delivery_limit_B)
        f(row,9,f"=MIN(H{ex},I{ex})" if i<30 else "=0",r.delivered_B)
        f(row,10,f"=MAX(0,H{ex}-J{ex})" if i<30 else "=0",r.queue_out_B)
        f(row,11,f"=E{ex}*Inputs!$B$7*D{ex}",r.recurring_B)
        f(row,12,f"=E{ex}*Inputs!$B$8*D{ex}",r.capacity_B)
        f(row,13,f"=E{ex}+L{ex}+J{ex}+M{ex}",r.B0_B)
        f(row,14,f"=E{ex}*D{ex}/Inputs!$B$2",r.weighted_factor)
        f(row,15,f"=O{ex}*Inputs!$B$11",r.price_B)
        f(row,16,f"=O{ex}*Inputs!$B$12*Inputs!$B$13",r.admin_B)
        f(row,17,f"=N{ex}-Q{ex}",r.B_B)
        f(row,18,f"=E{ex}-P{ex}",r.C_B)
        f(row,19,f"=N{ex}-P{ex}-Q{ex}",r.D_B)
        f(row,20,f"=T{ex}-E{ex}",r.D_minus_A_B)
        f(row,21,f"=U{ex}" if i==0 else f"=V{prev}+U{ex}",r.cumulative_D_minus_A_B)
        for col,source_cell,number in [(22,"B15",r.JAMA_diff_B),(23,"B16",r.Milliman_RAND_diff_B),
             (24,"B17",r.Milliman_HCCI_diff_B),(25,"B18",r.RAND_Milliman_diff_B)]:
            absolute_source=f"$B${source_cell[1:]}"
            f(row,col,f"=U{ex}-O{ex}*(Inputs!{absolute_source}-Inputs!$B$11-Inputs!$B$14)",number)
        for col,source_col,number in [(26,"U",r.PV_central_B),(27,"W",r.PV_JAMA_B),
             (28,"X",r.PV_Milliman_RAND_B),(29,"Y",r.PV_Milliman_HCCI_B),
             (30,"Z",r.PV_RAND_Milliman_B)]:
            f(row,col,f"={source_col}{ex}/((1+Inputs!$B$19)*(1+Inputs!$B$20))^(B{ex}-1)",number)
    sums.set_column("A:A",29);sums.set_column("B:G",23,fmt)
    sums.write_row(0,0,["Horizon","A $T","B0 $T","B $T","C $T","D $T","D-A $T"],header)
    for j,n in enumerate((5,10,20,30,100),start=1):
        sums.write_number(j,0,n)
        for k,attr,source in [(1,"A_B","E"),(2,"B0_B","N"),(3,"B_B","R"),(4,"C_B","S"),(5,"D_B","T"),(6,"D_minus_A_B","U")]:
            value=sum_years(corrected,attr,n)/1000
            sums.write_formula(j,k,f"=SUM('Annual 2025-2124'!{source}2:{source}{n+1})/1000",fmt,value)
    sums.write_row(8,0,["Price cases","30-year D-A $T","100-year D-A $T"],header)
    for j,(label,attr,source) in enumerate([("JAMA","JAMA_diff_B","W"),("Milliman + RAND","Milliman_RAND_diff_B","X"),
        ("Milliman + HCCI","Milliman_HCCI_diff_B","Y"),("RAND + Milliman","RAND_Milliman_diff_B","Z")],start=9):
        sums.write(j,0,label)
        for k,n in [(1,30),(2,100)]:
            sums.write_formula(j,k,f"=SUM('Annual 2025-2124'!{source}2:{source}{n+1})/1000",
                fmt,sum_years(corrected,attr,n)/1000)
    proof.set_column("A:A",39);proof.set_column("B:B",110)
    notes=[
        ("Status","New version. Do not substitute for or overwrite the historic four-document publication."),
        ("Found original B0 generator","Source Step48 workbook, Annual model rows 9/11-18/21, tied to Assumptions rows 7,10,11,14,15,18,19,25."),
        ("Reproduction","Legacy 2024 anchor $5,278.600B reproduces original 30-year B0 total $373.561245310T."),
        ("Corrected exact 2024 NHE","$5,278.588B. All year-by-year baseline and expansion values recalculated; no inferred B0 used."),
        ("Corrected 2024 personal healthcare","$4,510.222B. Used for informational 2024 component; not double-counted into A."),
        ("Separate unverified savings","Provider paperwork, new pharmaceutical procurement savings, medical debt, fraud and prevention remain $0 newly booked."),
        ("Unvalidated gates","Provider-safe payment, staffed capacity, cash transition and measured net clinical value remain unproven."),
        ("Century warning","2055-2124 is a 4% nominal extrapolation with 6% added care and 1% capacity; not a validated century forecast."),
        ("Alternative price warning","Deep-price cases use mixed source denominators and an assumed $25B annual-equivalent provider support."),
        ("Source files","Original Step48 and 100-year workbooks included separately under sources/; they are unchanged."),
    ]
    proof.write_row(0,0,["Field","Description"],header)
    for i,(name,note) in enumerate(notes,start=1):
        proof.write(i,0,name);proof.write(i,1,note)
    book.close()

def verify_generated_excel(corrected:list[Year],path:Path)->dict:
    cached=openpyxl.load_workbook(path,data_only=True,read_only=False)
    formulas=openpyxl.load_workbook(path,data_only=False,read_only=False)
    data=cached["Annual 2025-2124"]
    expressions=formulas["Annual 2025-2124"]
    column_attributes={
        3:"growth",4:"rollout",5:"A_B",6:"requests_B",7:"queue_in_B",
        8:"waiting_B",9:"delivery_limit_B",10:"delivered_B",11:"queue_out_B",
        12:"recurring_B",13:"capacity_B",14:"B0_B",15:"weighted_factor",
        16:"price_B",17:"admin_B",18:"B_B",19:"C_B",20:"D_B",
        21:"D_minus_A_B",22:"cumulative_D_minus_A_B",23:"JAMA_diff_B",
        24:"Milliman_RAND_diff_B",25:"Milliman_HCCI_diff_B",
        26:"RAND_Milliman_diff_B",27:"PV_central_B",28:"PV_JAMA_B",
        29:"PV_Milliman_RAND_B",30:"PV_Milliman_HCCI_B",
        31:"PV_RAND_Milliman_B",
    }
    max_delta=0.0
    for i,r in enumerate(corrected):
        for col,attribute in column_attributes.items():
            value=data.cell(i+2,col).value
            expression=expressions.cell(i+2,col).value
            assert isinstance(value,(int,float)),f"Missing cached result {i+2},{col}"
            assert isinstance(expression,str) and expression.startswith("="),f"Missing formula {i+2},{col}"
            max_delta=max(max_delta,abs(value-getattr(r,attribute)))
        assert expressions.cell(i+2,6).value==(f"=E{i+2}*Inputs!F{i+2}" if i<30 else "=0")
    assert max_delta<1e-8,f"Excel caches don't match generated data: {max_delta}B"
    for row,n in zip(range(2,7),(5,10,20,30,100)):
        for col,attr in ((2,"A_B"),(3,"B0_B"),(4,"B_B"),(5,"C_B"),(6,"D_B"),(7,"D_minus_A_B")):
            assert abs(cached["Summary"].cell(row,col).value-sum_years(corrected,attr,n)/1000)<1e-8
    cached.close();formulas.close()
    return {"tested_annual_formulas":len(corrected)*len(column_attributes),
            "tested_summary_cached_totals":30,
            "max_cached_vs_python_error_B":max_delta,
            "formula_rerun_note":"Cached values and formula presence audited; no independent Excel calculation engine was run"}

def main():
    inputs,original=load_sources()
    legacy=generate(inputs["old_anchor_B"],inputs)
    corrected=generate(inputs["corrected_anchor_B"],inputs)
    legacy_errors=verify_old_source(legacy,original)
    original_century_errors=compare_original_century(legacy)
    oldsum=summary(legacy)
    newsum=summary(corrected)
    check_original={
        "A_T":347.901098682,
        "B0_T":373.561245310,
        "B_T":369.066292471,
        "C_T":342.417162859,
        "D_T":363.582356648,
        "D_minus_A_T":15.681257966,
    }
    publication_residuals={k:oldsum["30"][k]-v for k,v in check_original.items()}
    if max(abs(x) for x in publication_residuals.values())>0.000001:
        raise AssertionError(f"Legacy final controls not reproduced within $1 million: {publication_residuals}")
    write_csv(legacy,HERE/"Legacy_2024_Working_Anchor_Reproduction.csv")
    write_csv(corrected,HERE/"Corrected_2024_Exact_Anchor_2025-2124.csv")
    corrected_book=HERE/"Universal_Healthcare_Source_Driven_Corrected_Model_v2.xlsx"
    write_excel(corrected,legacy,inputs,corrected_book)
    generated_excel_check=verify_generated_excel(corrected,corrected_book)
    result={
        "input_parameters":inputs,
        "historical_B0_source_comparison":legacy_errors,
        "historical_100yr_print_rounding_comparison":original_century_errors,
        "source_workbook_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (STEP48,CENTURY)},
        "historical_published_control_residuals_T":publication_residuals,
        "generated_excel_integrity":generated_excel_check,
        "legacy_outputs_T":oldsum,
        "corrected_outputs_T":newsum,
        "corrections_T":{h:{k:newsum[h][k]-oldsum[h][k] for k in newsum[h]} for h in newsum},
        "status":"source-driven arithmetic fixed; empirical feasibility still unvalidated"
    }
    (HERE/"Model_Correction_Reconciliation.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps({"legacy_30":oldsum["30"],"corrected_30":newsum["30"],"corrected_100":newsum["100"],
       "publication_control_residuals_T":publication_residuals,"source_B0_max_error_B":legacy_errors["B0_B"]["max_abs_B"]},indent=2))

if __name__=="__main__":
    main()
